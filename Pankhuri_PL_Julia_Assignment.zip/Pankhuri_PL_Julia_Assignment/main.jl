function make(x)
  cnt = 0
  function anon()
    cnt = cnt + x
    return(cnt)
  end
  function set()
    cnt = 0
    return(cnt)
  end
  return(anon, set)
end
R = make(2)
S = make(4)
println(R[1]()) # Julia starts with index 1
println(R[1]())  
println(R[2]())
println(S[1]())
println(R[1]())